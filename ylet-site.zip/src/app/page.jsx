import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const looks = [
  {
    title: "Look urbain chic",
    image: "/looks/look1.jpg",
  },
  {
    title: "Élégance ivoirienne",
    image: "/looks/look2.jpg",
  },
  {
    title: "Style Korhogo",
    image: "/looks/look3.jpg",
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white px-6 py-10">
      <header className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold tracking-wide text-gold">YLET</h1>
        <p className="mt-4 text-lg md:text-xl italic">Née pour faire la différence.</p>
        <p className="mt-2 text-sm md:text-base">YLET, c’est moi, mais c’est aussi toi. Si tu le portes, c’est que tu es né(e) pour faire la différence. – NISNHO YLET</p>
      </header>

      <section>
        <h2 className="text-2xl font-semibold mb-6">Lookbook YLET</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {looks.map((look, index) => (
            <Card
              key={index}
              className="rounded-2xl overflow-hidden transform transition duration-300 hover:scale-105 hover:shadow-lg"
            >
              <img
                src={look.image}
                alt={look.title}
                className="w-full h-64 object-cover"
              />
              <CardContent className="p-4 text-center">
                <h3 className="font-medium text-lg text-white">{look.title}</h3>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </main>
  );
}